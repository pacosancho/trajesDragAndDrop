const islas = ['El-Hierro', 'La-Palma', 'La-Gomera', 'Tenerife', 'Gran-Canaria', 'Fuerteventura', 'Lanzarote']

const imagenes = ['41-Traje-tipico-de-El-Hierro-hombre-min.png', '42-Traje-tipico-de-El-Hierro-mujer-min.png', '43-Traje-tipico-de-Fuerteventura-hombre-min.png',
  '44-Traje-tipico-de-Fuerteventura-mujer-min.png', '45-Traje-tipico-de-La-Gomera-hombre-min.png', '46-Traje-tipico-de-La-Gomera-mujer-min.png',
  '47-Traje-tipico-de-La-Palma-hombre-min.png', '48-Traje-tipico-de-La-Palma-mujer-min.png', '49-Traje-tipico-de-Lanzarote-hombre-min.png',
  '50-Traje-tipico-de-Lanzarote-mujer-min.png', '51-Traje-Tipico-Gran-Canaria-hombre-min.png', '52-Traje-tipico-Gran-Canaria-mujer-min.png',
  '53-Traje-tipico-Tenerife-hombre-min.png', '54-Traje-tipico-Tenerife-mujer-min.png']

/**
 *Genera las de 3 a 7 islas
 *
 * @param {String[]} islas
 * @returns {String[]} islasEscogidas
 */
function getIslasRandom (islas) {
  const islasEscogidas = []
  const nIslas = Math.floor(Math.random() * 4) + 4
  for (let i = 0; i < nIslas; i++) {
    const indiceIsla = Math.floor(Math.random() * (7 - i))
    islasEscogidas.push(islas[indiceIsla])
    islas.splice(indiceIsla, 1)
  }
  return islasEscogidas
}

const islasElegidas = getIslasRandom(islas)
const directorio = 'images/'
let dificultad
const misImagenes = []
// podria psarlo como parametro?
onClickMostrarTrajes()

/**
 *Muestra los trajes al hacer click en los botones
 *
 */
function onClickMostrarTrajes () {
  const nImg = [4, 6, 8]
  $('button').each(function () {
    $(this).click(function () {
      dificultad = nImg[$(this).prevAll('button').length]

      const imgEscogidas = getImagenesRandom(imagenes, islasElegidas)
      imgEscogidas.map(imagen => agregarImagen(imagen))

      for (let i = 0; i < dificultad; i++) {
        if (misImagenes[i] !== undefined) {
          $('.divClear').first().before($('<div id="' + misImagenes[i].src + '" class="ui-widget-content draggable"></div>'))
        }
      }
      let i = 0
      $('.draggable').each(function () {
        $(this).draggable({ containment: '#wrapper', /* cursor: "move", en css */ scroll: false })

        $(this).append($('<img src="' + misImagenes[i].src + '"></img>')) // si hago  $(this).append(img) no va por algun motivo

        i++
      })
      $('button').each(function () {
        $(this).off('click')
      })
    })
  })
}
/**
 *rellenamos el array de imagenes
 *
 * @param {*} imagen
 */
function agregarImagen (imagen) {
  const imgObj = new Image()
  imgObj.src = directorio + imagen
  misImagenes.push(imgObj) // retocar
}

/**
 *Coge las imagenes que perteenecen a las islas sacadas
 *
 * @param {String[]} imagenes
 * @param {String[]} islasElegidas
 * @returns {String[]} srcImagenes
 */
function getImagenesRandom (imagenes, islasElegidas) {
  const imagenesDeIslasMostradas = imagenes.filter(img => { return imgValida(img, islasElegidas) })

  return imagenesDeIslasMostradas
}

/**
 * Comprueba si la imagen pertenece a alguna de las islas
 *
 * @param {Object} img
 * @param {String[]} islasElegidas
 * @returns {boolean} valido
 */
function imgValida (img, islasElegidas) {
  let valido = false
  islasElegidas.forEach(isla => { if (img.includes(isla)) valido = true })
  return valido
}

toastr.options.closeButton = true
toastr.options.positionClass = 'toast-bottom-left'
function notification (type, message) {
  if (type === 'success') {
    toastr.success(message, 'Correcto')
  } else if (type === 'error') {
    toastr.error(message, 'Incorrecto')
  }
}
let acertados = 0
$(function () {
  const nIslas = islasElegidas.length

  $('#wrapper').each(function () {
    for (let i = 0; i < nIslas; i++) {
      $(this).append($('<div id="' + islasElegidas[i] + '" class="ui-widget-header droppable">' +
        '<p class="textCentered">' + islasElegidas[i] + '</p>' +
        '</div>'))
    }
    $('.droppable').first().before($('<div class="divClear" style="clear:both;"/>'))
  })

  let jugadas = 0
  $('.droppable').each(function () {
    $(this).droppable(
      {
        drop: function (event, ui) {
          let tipoNotificacion

          if (ui.draggable.attr('id').includes($(this).children().text())) {
            /* $(this)
            .addClass("ui-state-highlight")
            .find("p")
            .text("Dropped!"); */
            ui.draggable.draggable('disable')
            ui.draggable.css('border', '2px solid green')
            acertados++
            tipoNotificacion = 'success'
          } else {
            ui.draggable.css('border', '2px solid red')
            ui.draggable.draggable('disable')
            tipoNotificacion = 'error'
          }
          jugadas++
          const mensaje = 'Tienes ' + acertados + ' aciertos'
          if ((!$('body').children('p')[0]) && acertados > 0) {
            $('body').append($('<div class="divClear" style="clear:both;"/>'))
            $('body').append('<p>' + mensaje + '</p>')
          } else {
            $('body').children('p').text(mensaje)
          }
          notification(tipoNotificacion, mensaje)
          if (jugadas === dificultad) {
            mostrarModal(mensaje) // hay q pasar parametro pq la funcion esta fuera del scope
          }
        }
      })
  })
})

/**
 *Muestra el modal al finalizar el juego
 *
 * @param {String} mensaje
 */
function mostrarModal (mensaje) {
  $('body').append($('<div id="dialog-confirm" title="Juego terminado!!">' +
            '<p>' + mensaje + '</p>' +
          '</div>'))
  $(function () {
    $('#dialog-confirm').dialog({
      resizable: false,
      height: 'auto',
      width: 400,
      modal: true,
      show: {
        effect: 'fade',
        duration: 500
      },
      hide: {
        effect: 'explode',
        duration: 500
      },
      buttons: {
        'Jugar de nuevo': function () {
          location.reload()
        }

      }
    })
  })
}
